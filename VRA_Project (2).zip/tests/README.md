# tests
Unit tests live in `frontend/test` (Flutter requires that location): compat decision logic and root policy.
Guest boot, guest root, guest install/launch, shutdown and disk backup tests cannot exist until the guest does. They are NOT implemented and not claimed.
