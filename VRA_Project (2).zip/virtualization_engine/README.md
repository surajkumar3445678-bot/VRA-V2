# virtualization_engine
Step 2 (done in code, untested on device): `fetch_qemu.py` downloads a prebuilt aarch64 QEMU from the Termux
package repo during the GitHub build, repackages it as `libqemu.so` plus renamed dependency libs, and
`GuestManager.qemuSmokeTest` runs it (`--version`, `-accel help`) so the Boot screen shows real output.
Step 3: guest image + kernel + launch. Not implemented.
QEMU is GPLv2 (https://www.qemu.org/).

Step 3a: `GuestManager.kernelTest` boots a small Alpine Linux guest (kernel + initramfs fetched in the GitHub build) with `-M virt -accel tcg` and returns its console log. This is Linux, not Android. Step 3b (Android image) is not implemented.
