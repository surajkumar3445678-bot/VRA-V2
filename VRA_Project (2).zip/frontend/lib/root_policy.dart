/// Guest-only root policy store. It records decisions for guest apps and
/// never touches host permissions. Enforcement needs a guest-side su daemon
/// that reads this policy (not yet implemented, see README).
class RootEntry {
  final String package;
  bool granted;
  final DateTime since;
  RootEntry(this.package, this.granted, this.since);
}

class RootLogLine {
  final DateTime time;
  final String package;
  final String action;
  RootLogLine(this.time, this.package, this.action);
}

class RootPolicy {
  final Map<String, RootEntry> _entries = {};
  final List<RootLogLine> _log = [];
  final DateTime Function() now;
  RootPolicy({DateTime Function()? clock}) : now = clock ?? DateTime.now;

  List<RootEntry> get entries => _entries.values.toList();
  List<RootLogLine> get log => List.unmodifiable(_log);

  bool isGranted(String pkg) => _entries[pkg]?.granted ?? false;

  void grant(String pkg) {
    _entries[pkg] = RootEntry(pkg, true, now());
    _log.add(RootLogLine(now(), pkg, 'granted'));
  }

  void revoke(String pkg) {
    final e = _entries[pkg];
    if (e == null) return;
    e.granted = false;
    _log.add(RootLogLine(now(), pkg, 'revoked'));
  }

  /// Guest su request. Unknown or revoked apps are denied and logged.
  bool request(String pkg) {
    final ok = isGranted(pkg);
    _log.add(RootLogLine(now(), pkg, ok ? 'su allowed' : 'su denied'));
    return ok;
  }

  Map<String, dynamic> toJson() => {
        'entries': [
          for (final e in _entries.values)
            {'p': e.package, 'g': e.granted, 't': e.since.toIso8601String()}
        ],
      };

  void loadJson(Map<String, dynamic> j) {
    for (final e in (j['entries'] as List? ?? [])) {
      _entries[e['p']] = RootEntry(e['p'], e['g'] == true, DateTime.parse(e['t']));
    }
  }
}
