package dev.vra.host

import android.content.Context
import android.system.Os
import java.io.File

/** Locates guest files. Launching QEMU is not implemented yet and says so. */
object GuestManager {
    private fun image(ctx: Context) = File(ctx.filesDir, "guest/system.img")
    private fun qemu(ctx: Context) = File(ctx.applicationInfo.nativeLibraryDir, "libqemu.so")

    fun status(ctx: Context): Map<String, Any> {
        val img = image(ctx)
        return mapOf(
            "installed" to img.isFile,
            "imagePath" to img.absolutePath,
            "imageBytes" to (if (img.isFile) img.length() else 0L),
            "qemuPresent" to qemu(ctx).isFile,
        )
    }

    fun boot(ctx: Context): Map<String, Any> {
        if (!image(ctx).isFile)
            return mapOf("ok" to false, "reason" to "No guest image at ${image(ctx).absolutePath}.")
        if (!qemu(ctx).isFile)
            return mapOf("ok" to false, "reason" to "No QEMU binary packaged with this build.")
        return mapOf("ok" to false, "reason" to "Image and QEMU found, but the QEMU launcher is not implemented in this build, so nothing was started.")
    }

    private fun prepareLibLinks(ctx: Context): File {
        val dir = File(ctx.filesDir, "qemu-libs")
        dir.deleteRecursively()
        dir.mkdirs()
        val nat = ctx.applicationInfo.nativeLibraryDir
        ctx.assets.open("qemu_libmap.txt").bufferedReader().useLines { lines ->
            for (l in lines) {
                val p = l.split("=")
                if (p.size == 2 && p[0].isNotBlank()) {
                    val target = File(nat, p[1])
                    if (target.isFile) Os.symlink(target.absolutePath, File(dir, p[0]).absolutePath)
                }
            }
        }
        return dir
    }

    private fun runQemu(ctx: Context, q: File, linkDir: File, args: List<String>): String {
        val pb = ProcessBuilder(listOf(q.absolutePath) + args).redirectErrorStream(true)
        pb.environment()["LD_LIBRARY_PATH"] = linkDir.absolutePath + ":" + ctx.applicationInfo.nativeLibraryDir
        val p = pb.start()
        val out = StringBuilder()
        val t = Thread { p.inputStream.bufferedReader().forEachLine { out.appendLine(it) } }
        t.start()
        t.join(15000)
        if (t.isAlive) {
            p.destroy()
            return out.toString().trim() + "\n(timed out after 15 s)"
        }
        val code = p.waitFor()
        return out.toString().trim() + "\n(exit code $code)"
    }

    /** Runs the packaged QEMU for real and returns what it printed. Starts no guest. */
    fun qemuSmokeTest(ctx: Context): Map<String, Any> {
        val q = qemu(ctx)
        if (!q.isFile)
            return mapOf("ok" to false, "output" to "QEMU is not packaged in this build (libqemu.so missing).")
        return try {
            val linkDir = prepareLibLinks(ctx)
            val sb = StringBuilder()
            for (args in listOf(listOf("--version"), listOf("-accel", "help"))) {
                sb.append("$ qemu ${args.joinToString(" ")}\n")
                sb.append(runQemu(ctx, q, linkDir, args)).append("\n\n")
            }
            mapOf("ok" to true, "output" to sb.toString().trim())
        } catch (e: Exception) {
            mapOf("ok" to false, "output" to "Could not run QEMU: ${e.message}")
        }
    }

    private fun guestFile(ctx: Context, name: String): File? {
        val f = File(File(ctx.filesDir, "guest"), name)
        if (f.isFile) return f
        return try {
            f.parentFile?.mkdirs()
            ctx.assets.open(name).use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            f
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Boots a small Linux guest (NOT Android) under QEMU software emulation and returns its
     * serial console log, to prove the guest runs its own kernel. Stops it after 60 s.
     */
    fun kernelTest(ctx: Context): Map<String, Any> {
        val q = qemu(ctx)
        if (!q.isFile) return mapOf("ok" to false, "output" to "QEMU is not packaged in this build.")
        val kernel = guestFile(ctx, "vmlinuz-virt")
        val initrd = guestFile(ctx, "initramfs-virt")
        if (kernel == null || initrd == null)
            return mapOf("ok" to false, "output" to "Test kernel files are not packaged in this build.")
        return try {
            val linkDir = prepareLibLinks(ctx)
            val args = listOf(
                "-M", "virt", "-cpu", "cortex-a72", "-m", "512", "-smp", "2", "-accel", "tcg",
                "-kernel", kernel.absolutePath, "-initrd", initrd.absolutePath,
                "-append", "console=ttyAMA0",
                "-nodefaults", "-display", "none", "-serial", "stdio", "-monitor", "none", "-nic", "none"
            )
            val pb = ProcessBuilder(listOf(q.absolutePath) + args).redirectErrorStream(true)
            pb.environment()["LD_LIBRARY_PATH"] = linkDir.absolutePath + ":" + ctx.applicationInfo.nativeLibraryDir
            val p = pb.start()
            val lines = java.util.Collections.synchronizedList(ArrayList<String>())
            val t = Thread {
                try {
                    p.inputStream.bufferedReader().forEachLine { if (lines.size < 150) lines.add(it) }
                } catch (e: Exception) {
                }
            }
            t.start()
            val start = System.currentTimeMillis()
            while (t.isAlive && System.currentTimeMillis() - start < 60000) Thread.sleep(500)
            val timedOut = t.isAlive
            p.destroy()
            val text = synchronized(lines) { lines.joinToString("\n") }
            val booted = text.contains("Linux version")
            val body = if (text.isBlank()) "(no output)" else text
            mapOf("ok" to booted, "output" to body + (if (timedOut) "\n(stopped after 60 s)" else ""))
        } catch (e: Exception) {
            mapOf("ok" to false, "output" to "Could not start guest: ${e.message}")
        }
    }
}
